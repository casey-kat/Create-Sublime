Hey there, we're guessing you're here for the express reason of finding out what we would like you to do with our pack (if you will oh so courteously obligle),
or you like our trivia for some reason.

What you can do with our resource pack:
- If we suddenly die, or dissapear from the internet, and we answer no replies from anyone, ever, for a while (Like at least half a year), then yes you can freely use this pack for whatever you want,
remixing it, continuing to update it, etc. Just at least attempt to contact us on Discord first.
- You may modify this for personal use, and yes you can privately send your customized version to friends, just no publishing it anywhere and saying you made it.
- You may use this in videos, why would we make a pack where you can't?
- Of course you can download it, you already did that.
- Yes, you can take inspiration.
- Yes, you can pick through the files to see how we did stuff to learn how to do it yourself! (If you're interested in modeling blocks/items, use Blockbench).
However, joining the Discord (https://discord.gg/hQqx2mqMz8) would probably be a lot more beneficial to you!
- You may NOT smell the textures.
- Just use common sense, this is obviously free for personal use bla bla bla don't republish it bla bla license all rights reserved bla bla bla.

<><>Now have some trivia as a reward for clicking on the readme!<><>

Cool Trivia:
- This took way too long to make.
- It was pain.
- Please enjoy.